#ifndef CHARACTERS_H
#define CHARACTERS_H

#include "objects/MainBird.h"
#include "objects/Ground.h"
#include "objects/Background.h"
#include "objects/Pipe.h"
#include "objects/GameOver.h"

#endif